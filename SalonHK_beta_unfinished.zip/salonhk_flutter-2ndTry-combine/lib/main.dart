import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:salonhk_flutter/controllers/auth.dart';
import 'package:salonhk_flutter/views/wrapper.dart';
import 'package:salonhk_flutter/vinsonscodes/bookingpage.dart';
import 'package:salonhk_flutter/vinsonscodes/followingpage.dart';
import 'package:salonhk_flutter/vinsonscodes/historypage.dart';
import 'package:salonhk_flutter/vinsonscodes/loadingpage.dart';
import 'package:salonhk_flutter/vinsonscodes/main.dart';
import 'package:salonhk_flutter/vinsonscodes/userpersonalpage.dart';
import 'models/user.dart';
import 'views/login.dart';

//TODO: Register iOS app to Firebase (I don't have iPhone :() https://firebase.google.com/docs/flutter/setup?authuser=1&platform=ios
//TODO: iOS facebook auth setup https://pub.dev/packages/flutter_facebook_auth
//TODO: iOS apple https://firebase.flutter.dev/docs/auth/social
//TODO: iOS phone verification https://firebase.google.com/docs/auth/ios/phone-auth
//TODO: Google play (maybe need to also update facebook auth)

void main() {
  runApp(Authenticate());
}

class Authenticate extends StatefulWidget {
  _AuthenticateState createState() => _AuthenticateState();
}

class _AuthenticateState extends State<Authenticate> {
  bool _initialized = false;
  bool _error = false;

  void initializeFlutterFire() async {
    try {
      await Firebase.initializeApp();
      setState(() {
        _initialized = true;
      });
    } catch (e) {
      setState(() {
        _error = true;
      });
    }
  }

  @override
  void initState() {
    initializeFlutterFire();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    if (_error) {
      return MaterialApp(
        home: Text('Error!'),
      );
    }

    if (!_initialized) {
      return MaterialApp(
        home: Text('Loading...'),
      );
    }


    return StreamProvider<MyUser>.value(
      value: Auth().user,
      child: MaterialApp(
        routes: {
          '/wrapper': (context) => Wrapper(),
          '/loading': (context) => Loading(),
          '/barberhk': (context) => BarberHK(),
          '/loginpage': (context) => LoginPage(),
          '/userpersonalpage' : (context) => PersonalPage(),
          '/followingpage' : (context) => FollowingPage(),
          '/historypage' : (context) => HistoryPage(),
          '/bookingpage' : (context) => BookingPage(),
        },
        title: 'SalonHK',
        theme: ThemeData(
          primarySwatch: Colors.blueGrey,
          visualDensity: VisualDensity.adaptivePlatformDensity,
        ),
        initialRoute: '/wrapper',
      ),
    );
  }
}
