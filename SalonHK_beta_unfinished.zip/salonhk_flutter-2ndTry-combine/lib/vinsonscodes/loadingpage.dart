import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:salonhk_flutter/controllers/database.dart';
import 'dart:async';
import 'package:salonhk_flutter/models/user.dart';
import 'package:provider/provider.dart';
import 'package:salonhk_flutter/main.dart';
import 'package:salonhk_flutter/vinsonscodes/main.dart';

class Loading extends StatefulWidget {
  @override
  _LoadingState createState() => _LoadingState();
}

class _LoadingState extends State<Loading> {
  String currentUserName = "";
  String currentUserEmail = "";
  Map <dynamic,dynamic> currentUserAccInfo;

  void setupDelay() async {
    Future.delayed(const Duration(seconds: 1), () {
      print("My current User(setupDelay):  " + currentUserName);
      setState(() {
        // Here you can write your code for open new view
      });
    });

    //  Navigator.pushNamed(context, '/home',arguments:{}) -> loading page underneath, and the arguments is a "Map" that pass data to '/home' route
    // Navigator.pushReplacementNamed(context, '/home') -> No page underneath and the routing stack remain only 'home' page
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
//    setupDelay();
  }

  @override
  Widget build(BuildContext context) {
    final users = Provider.of<List<MyUserInfo>>(context) ?? []; // get data by Database service
    users.forEach((i) {
      if (i.uid == FirebaseAuth.instance.currentUser.uid) { //search for specific user data
        currentUserName = i.name;
        currentUserEmail = i.email;
        currentUserAccInfo = i.userAccInfo;
      }
    });
//    print("My current User:  " + currentUserName);

    return Scaffold(
        backgroundColor: Colors.blueGrey[400],
        body: SafeArea(
          child: Center(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(60.0),
                  child: Text("Welcome, " + currentUserName,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 50
                    ),),
                ),
                SizedBox(height: 50,),
                SpinKitCubeGrid(
                  color: Colors.white,
                  size: 50.0,
                ),
                SizedBox(height: 200,),
                FlatButton(
                  onPressed: () {
                    setState(() {
                      print("My current User:  " + currentUserName);
                      Navigator.pushReplacementNamed(context, '/barberhk',
                          arguments: {'currentUserName': currentUserName,'currentUserEmail':currentUserEmail,'currentUserAccInfo':currentUserAccInfo});
                    });
                  },
                  color: Colors.blueGrey[800],
                  child: Padding(
                    padding: const EdgeInsets.all(12.0),
                    child: Text('GO TO SALON HK!',style: TextStyle(color: Colors.white),),
                  ),
                ),

              ],
            ),
          ),
        ));
  }
}


class LoadingNoWait extends StatefulWidget {
  @override
  _LoadingNoWaitState createState() => _LoadingNoWaitState();
}

class _LoadingNoWaitState extends State<Loading> {
  String currentUserName = "";
  String currentUserEmail = "";
  Map <dynamic,dynamic> currentUserAccInfo;

  void setupDelay() async {
    Future.delayed(const Duration(seconds: 1), () {
      print("My current User(setupDelay):  " + currentUserName);
      setState(() {


        // Here you can write your code for open new view
      });
    });

    //  Navigator.pushNamed(context, '/home',arguments:{}) -> loading page underneath, and the arguments is a "Map" that pass data to '/home' route
    // Navigator.pushReplacementNamed(context, '/home') -> No page underneath and the routing stack remain only 'home' page
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    var users;

    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      users = Provider.of<List<MyUserInfo>>(context, listen: false);
    });

    users.forEach((i) {
      if (i.uid == FirebaseAuth.instance.currentUser.uid) { //search for specific user data
        currentUserName = i.name;
        currentUserEmail = i.email;
        currentUserAccInfo = i.userAccInfo;
      }
    });
//    print("My current User:  " + currentUserName);

    print("My current User:  " + currentUserName);
    Navigator.pushReplacementNamed(context, '/barberhk',
        arguments: {'currentUserName': currentUserName,'currentUserEmail':currentUserEmail,'currentUserAccInfo':currentUserAccInfo});
//    setupDelay();
  }

  @override
  Widget build(BuildContext context) {
    final users = Provider.of<List<MyUserInfo>>(context) ?? []; // get data by Database service
    users.forEach((i) {
      if (i.uid == FirebaseAuth.instance.currentUser.uid) { //search for specific user data
        currentUserName = i.name;
        currentUserEmail = i.email;
        currentUserAccInfo = i.userAccInfo;
      }
    });
//    print("My current User:  " + currentUserName);

//      print("My current User:  " + currentUserName);
//      Navigator.pushReplacementNamed(context, '/barberhk',
//          arguments: {'currentUserName': currentUserName,'currentUserEmail':currentUserEmail,'currentUserAccInfo':currentUserAccInfo});
    return Scaffold(
        backgroundColor: Colors.blueGrey[400],
        body: SafeArea(
          child: Center(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(60.0),
                  child: Text("Welcome, " + currentUserName,
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 50
                    ),),
                ),
                SizedBox(height: 50,),
                SpinKitCubeGrid(
                  color: Colors.white,
                  size: 50.0,
                ),
                SizedBox(height: 200,),
              ],
            ),
          ),
        ));
  }
}