import 'package:flutter/material.dart';
import 'userinfods.dart';
import 'package:salonhk_flutter/kennethscodes/shop_details.dart';

class FollowingPage extends StatefulWidget {
  @override
  _FollowingPageState createState() => _FollowingPageState();
}

class _FollowingPageState extends State<FollowingPage> {
  Map data;
  List<SalonShopDetails> followingList = [];
  @override
  Widget build(BuildContext context) {
    data = ModalRoute.of(context).settings.arguments;
    followingList = (data["followingList"] != null) ? data["followingList"] : [];

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(backgroundColor: Colors.blueGrey[400],title: Text('My Following')),
      body: ListView(
          padding: EdgeInsets.zero,
          scrollDirection: Axis.vertical,
          children: followingList.map((item) => FlatButton(
            padding: EdgeInsets.zero,
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(
                  builder: (context)=>SalonPage(index: item.shopName, address: item.shopAddr, path:item.shopIconAddr,script: item.shopDesciption),
              ));
            },
            child: Card(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(18.0),
                  side: BorderSide(color: Colors.grey[300])),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(12,0,16,0),
                    child: Image(
                      image: AssetImage(item.shopIconAddr),
                      height: 120,
                      width: 120,
                    ),
                  ),
                  Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.fromLTRB(0, 10, 0, 0),
                          child: Text(
                            item.shopName,
                            style: TextStyle(fontSize: 15),
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Container(
                          width: 250,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Text(
                                    item.postsAmount,
                                    style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold),
                                  ),
                                  Text(
                                    ' posts',
                                    style: TextStyle(fontSize: 12),
                                  ),
                                  SizedBox(width: 20),
                                  Text(
                                    item.followersAmount,
                                    style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold),
                                  ),
                                  Text(
                                    ' followers',
                                    style: TextStyle(fontSize: 12),
                                  ),
                                  SizedBox(width: 20),
                                  Text(
                                    item.followingAmount,
                                    style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold),
                                  ),
                                  Text(
                                    ' following',
                                    style: TextStyle(fontSize: 12),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: 20),
                        Text(
                          item.shopDesciption,
                          style: TextStyle(fontSize: 12),
                        ),
                      ])
                ],
              ),
            ),
          )).toList()

          ),
    );
  }
}
