import 'package:flutter/material.dart';
import 'homepagelayout/search_by_tag_block.dart';
import 'homepagelayout/latest_feed_block.dart';
import 'userinfods.dart';
import 'package:salonhk_flutter/kennethscodes/main.dart';


class Homepage extends StatefulWidget {
  final UserAccInfo currentUserAcc;
  Homepage({this.currentUserAcc});
  @override
  _HomepageState createState() => _HomepageState();
}

class _HomepageState extends State<Homepage> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[300],
      appBar: AppBar(

        title:Text('Salon HK'),
        centerTitle: true,
        backgroundColor: Colors.blueGrey[400],
        elevation: 0.0,
      ),
      body: Padding(
          padding: EdgeInsets.fromLTRB(10.0, 0.0, 10.0, 0.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                flex: 3,
                child: Column(
                  children: [
                    Expanded(
                      child:  Container(
                        margin: EdgeInsets.symmetric(horizontal: 10.0,vertical: 8.0),
                        decoration: BoxDecoration(
                            color:Colors.grey[400],
                            borderRadius: BorderRadius.all(Radius.circular(22.0))
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              flex: 1,
                              child: FlatButton(
                                  onPressed: (){
                                    Navigator.push(context, MaterialPageRoute(
                                      builder: (context)=>SearchingPage(),
                                    ));
                                  },
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Icon(Icons.search),
                                      Center(
                                        child: Text(
                                            'Search'
                                        ),
                                      ),
                                    ],
                                  )),
                            )
                          ],
                        ),
                      ),
                    ),

                    SizedBox(height: 10,),
                    Expanded(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          CircleAvatar(
                            radius:20.0,
                            backgroundImage:AssetImage(widget.currentUserAcc.userIconAddr),
                            backgroundColor: Colors.grey[300],
                          ),
                          SizedBox(width: 20,),
                          Text("Welcome,  " + widget.currentUserAcc.userName)
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                flex: 4,
                child: SearchByTagBlk(),
              ),
              Expanded(
                flex: 8,
                child: LatestFeedBlk(),
              )
            ],
          )
      ),
    );
  }
}

