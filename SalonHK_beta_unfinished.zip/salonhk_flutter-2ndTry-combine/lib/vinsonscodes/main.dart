import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:salonhk_flutter/controllers/database.dart';
import 'homepage.dart';
import 'userpersonalpage.dart';
import 'loginpage.dart';
import 'loadingpage.dart';
import 'userinfods.dart';
import 'followingpage.dart';
import 'historypage.dart';
import 'bookingpage.dart';
import 'package:salonhk_flutter/models/user.dart';

void main() {
  runApp(MaterialApp(
    routes: {
      '/': (context) => Loading(),
      '/home': (context) => BarberHK(),
      '/loginpage': (context) => LoginPage(),
      '/userpersonalpage' : (context) => PersonalPage(),
      '/followingpage' : (context) => FollowingPage(),
      '/historypage' : (context) => HistoryPage(),
      '/bookingpage' : (context) => BookingPage(),
    },
    initialRoute: '/',
    debugShowCheckedModeBanner: false,
  ));
}
//
//class BarberHK extends StatefulWidget {
//
//  @override
//  _BarberHKState createState() => _BarberHKState();
//}
//
//class _BarberHKState extends State<BarberHK> {
//
//}

class BarberHK extends StatelessWidget {
    Map userDataAfterLogin = {};
    Map userDataPassedFromLoading = {};
    String _currentUserName = '';
    String _currentUserEmail = '';
    Map<dynamic,dynamic> _currentUserAccInfo;
    @override
    Widget build(BuildContext context) {
      userDataPassedFromLoading = ModalRoute.of(context).settings.arguments;
      _currentUserName = userDataPassedFromLoading['currentUserName'];
      _currentUserEmail = userDataPassedFromLoading['currentUserEmail'];
      _currentUserAccInfo = userDataPassedFromLoading['currentUserAccInfo'];
      print("Current User booking count in BarberHK page: ");
      print(_currentUserAccInfo['bookingCount']);
//    userDataAfterLogin = ModalRoute.of(context).settings.arguments;

      return MyBottomNavigationBar(currentUser: userDataAfterLogin['currentUser']??UserAccInfo(
          userName:'',
          userEmail:'',
          userIconAddr: 'assets/emptyAvatar.png',
          followingListIconAddr:[],
          historyListIconAddr:[],
          bookingCount: 0,
          userAcc: '',
          userPwd: '',
          isLogin: 0,
          bookingRec: [],
          followingList: [],
          browsingHistory: []
      ),userNameMatching: _currentUserName,userEmailMatching: _currentUserEmail,currentUserAccInfo: _currentUserAccInfo,);
    }

}


class MyBottomNavigationBar extends StatefulWidget {
  UserAccInfo currentUser;
  String userNameMatching;
  String userEmailMatching;
  Map<dynamic,dynamic> currentUserAccInfo;
  MyBottomNavigationBar({this.currentUser,this.userNameMatching,this.userEmailMatching,this.currentUserAccInfo});
  @override
  _MyBottomNavigationBarState createState() => _MyBottomNavigationBarState();
}

class _MyBottomNavigationBarState extends State<MyBottomNavigationBar> {
  int _currentIdx = 0;
  List <UserAccInfo> userAccDB = [
    UserAccInfo(
        userName:'Lily',
        userEmail:'lily@gmail.com',
        userIconAddr: 'assets/lilyAvatar.png',
        followingListIconAddr:['assets/beautySalon.png'],
        historyListIconAddr:['assets/beautySalon.png', 'assets/abcSalon.jpg', 'assets/primeSalon.png'],
        bookingCount: 3,
        userAcc: 'vinson123',
        userPwd: 'abc123',
        isLogin: 1,
        bookingRec: [
          BookingDetails(branchName: "Beauty Salon",bookingID: "00001",serviceDescription:"Washing,Cutting and Browing",
            moneyPaid: "USD\$200",appointmentDate: "06/09/2020",bookingQuantity: "1",branchIconAddr: "assets/beautySalon.png"),
          BookingDetails(branchName: "ABC Salon",bookingID: "00002",serviceDescription:"Washing,Cutting and Browing",
            moneyPaid: "USD\$100",appointmentDate: "20/09/2020",bookingQuantity: "1",branchIconAddr: "assets/abcSalon.jpg"),
          BookingDetails(branchName: "Prime Salon",bookingID: "00003",serviceDescription:"Facial Treatment",
            moneyPaid: "USD\$50",appointmentDate: "07/10/2020",bookingQuantity: "1",branchIconAddr: "assets/primeSalon.png"),
        ],
        followingList: [
          SalonShopDetails(shopName: "Beauty Salon",postsAmount: "3908",followersAmount: "4000",followingAmount: "2",
              shopDesciption: "To be the best barber shop in the world\nWe have 200 branches around the world\n",
              shopIconAddr: "assets/beautySalon.png"),
        ],
        browsingHistory: [
          SalonShopDetails(shopName: "Beauty Salon",postsAmount: "3908",followersAmount: "4000",followingAmount: "2",
              shopDesciption: "To be the best barber shop in the world\nWe have 200 branches around the world\n",
              shopIconAddr: "assets/beautySalon.png"),
          SalonShopDetails(shopName: "ABC Salon",postsAmount: "1000",followersAmount: "10K",followingAmount: "13",
              shopDesciption: "ABC Salon give you a perfect hairstyle \nWe have 120 branches around the world\n",
              shopIconAddr: "assets/abcSalon.jpg"),
          SalonShopDetails(shopName: "Prime Salon",postsAmount: "2111",followersAmount: "32K",followingAmount: "37",
              shopDesciption: "Prime Salon offer you a good experience\nWe have 64 branches around the world\n",
              shopIconAddr: "assets/primeSalon.png"),
        ]
    ),
    UserAccInfo(
        userName:'John Liu',
        userEmail:'johnliu1997@gmail.com',
        userIconAddr: 'assets/johnliuAvatar.jpg',
        followingListIconAddr:['assets/beautySalon.png',"assets/salontic.jpg"],
        historyListIconAddr:['assets/beautySalon.png',"assets/abcSalon.jpg","assets/primeSalon.png", 'assets/salontic.jpg','assets/lovehairSalon.png'],
        bookingCount: 2,
        userAcc: 'johnliu1997',
        userPwd: 'bba2233',
        isLogin: 1,
        bookingRec: [
          BookingDetails(branchName: "Beauty Salon",bookingID: "00001",serviceDescription:"Washing,Cutting and Browing",
              moneyPaid: "USD\$200",appointmentDate: "06/09/2020",bookingQuantity: "1",branchIconAddr: "assets/beautySalon.png"),
          BookingDetails(branchName: "TIC Salon",bookingID: "00002",serviceDescription:"Washing,Cutting and Browing",
              moneyPaid: "USD\$100",appointmentDate: "20/09/2020",bookingQuantity: "1",branchIconAddr: "assets/salontic.jpg"),
        ],
        followingList: [
          SalonShopDetails(shopName: "Beauty Salon",postsAmount: "3908",followersAmount: "4000",followingAmount: "2",
              shopDesciption: "To be the best barber shop in the world\nWe have 200 branches around the world\n",
              shopIconAddr: "assets/beautySalon.png",shopAddr: "Merlin Building, 30-34 Cochrane St, Central"),
          SalonShopDetails(shopName: "TIC Salon",postsAmount: "6501",followersAmount: "10k",followingAmount: "10",
              shopDesciption: "TIC Salon has the best salon team\n We have served amount 10k people per day\n...",
              shopIconAddr: "assets/salontic.jpg",shopAddr: '827, 1 Matheson St, Causeway Bay'),
        ],
        browsingHistory: [
          SalonShopDetails(shopName: "Beauty Salon",postsAmount: "3908",followersAmount: "4000",followingAmount: "2",
              shopDesciption: "To be the best barber shop in the world\nWe have 200 branches around the world\n",
              shopIconAddr: "assets/beautySalon.png",shopAddr: "Merlin Building, 30-34 Cochrane St, Central"),
          SalonShopDetails(shopName: "ABC Salon",postsAmount: "1000",followersAmount: "10K",followingAmount: "13",
              shopDesciption: "ABC Salon give you a perfect hairstyle \nWe have 120 branches around the world\n",
              shopIconAddr: "assets/abcSalon.jpg",shopAddr: '2 Tong Ming St, Tseung Kwan O'),
          SalonShopDetails(shopName: "Prime Salon",postsAmount: "2111",followersAmount: "32K",followingAmount: "37",
              shopDesciption: "Prime Salon offer you a good experience\nWe have 64 branches around the world\n",
              shopIconAddr: "assets/primeSalon.png",shopAddr: '2/F, Howard Building, 42 Hankow Rd, Tsim Sha Tsui'),
          SalonShopDetails(shopName: "TIC Salon",postsAmount: "6501",followersAmount: "10k",followingAmount: "10",
              shopDesciption: "TIC Salon has the best salon team\n We have served amount 10k people per day\n...",
              shopIconAddr: "assets/salontic.jpg",shopAddr: '827, 1 Matheson St, Causeway Bay'),
          SalonShopDetails(shopName: "Love Hair Salon",postsAmount: "3312",followersAmount: "100k",followingAmount: "5",
              shopDesciption: "Love Hair Salon located in Central Hong Kong\n Giving you a luxury hairstyling experience\n...",
              shopIconAddr: "assets/lovehairSalon.png",shopAddr: '99F Wellington St, Central'),
        ]
    ),
    UserAccInfo(
        userName:'Vinson',
        userEmail:'vinson@gmail.com',
        userIconAddr: 'assets/emptyAvatar.png',
        followingListIconAddr:[],
        historyListIconAddr:[],
        bookingCount: 0,
        userAcc: '',
        userPwd: '',
        isLogin: 1,
        bookingRec: [
        ],
        followingList: [
        ],
        browsingHistory: [
        ]
    )
  ];

  final List<Widget> _children = [];
  void onTappedBar(int idx){
    setState(() {
      _currentIdx = idx;
    });
  }

  UserAccInfo loadDataInDS(Map<dynamic,dynamic> currentUserAccInfo){
    UserAccInfo currentUserFinal = UserAccInfo(
      userName: widget.currentUserAccInfo['userName'],
      userEmail: widget.currentUserAccInfo['userEmail'],
      userIconAddr: widget.currentUserAccInfo['userIconAddr'],
      userAcc: widget.currentUserAccInfo['userAcc'],
      userPwd: widget.currentUserAccInfo['userPwd'],
      isLogin: widget.currentUserAccInfo['isLogin'],

    );
    List<dynamic> followingListIconAddr = widget.currentUserAccInfo['followingListIconAddr'];
    List<dynamic> historyListIconAddr = widget.currentUserAccInfo['historyListIconAddr'];

    currentUserFinal.followingListIconAddr = List<String>();
    currentUserFinal.historyListIconAddr = List<String>();
    currentUserFinal.bookingRec = List<BookingDetails>();
    currentUserFinal.followingList = List<SalonShopDetails>();
    currentUserFinal.browsingHistory = List<SalonShopDetails>();

    currentUserFinal.followingListIconAddr.addAll(followingListIconAddr.cast<String>().toList());
    currentUserFinal.historyListIconAddr.addAll(historyListIconAddr.cast<String>().toList());
    currentUserFinal.bookingCount = widget.currentUserAccInfo['bookingRec'].length;

    widget.currentUserAccInfo['bookingRec'].forEach((i){
      currentUserFinal.bookingRec.add(
          BookingDetails(
              branchName:i['BookingDetails']['branchName'],
              appointmentDate: i['BookingDetails']['appointmentDate'],
              bookingID: i['BookingDetails']['bookingID'],
              bookingQuantity: i['BookingDetails']['bookingQuantity'],
              branchIconAddr: i['BookingDetails']['branchIconAddr'],
              moneyPaid: i['BookingDetails']['moneyPaid'],
              serviceDescription: i['BookingDetails']['serviceDescription'])
      );
    });

    widget.currentUserAccInfo['followingList'].forEach((i){
      currentUserFinal.followingList.add(
          SalonShopDetails(
              shopName: i['SalonShopDetails']['shopName'],
              postsAmount: i['SalonShopDetails']['postsAmount'],
              followingAmount: i['SalonShopDetails']['followingAmount'],
              followersAmount: i['SalonShopDetails']['followersAmount'],
              shopDesciption: i['SalonShopDetails']['shopDesciption'],
              shopIconAddr: i['SalonShopDetails']['shopIconAddr'],
              shopAddr: i['SalonShopDetails']['shopAddr']
          )
      );
    });

    widget.currentUserAccInfo['browsingHistory'].forEach((i){
      currentUserFinal.browsingHistory.add(
          SalonShopDetails(
              shopName: i['SalonShopDetails']['shopName'],
              postsAmount: i['SalonShopDetails']['postsAmount'],
              followingAmount: i['SalonShopDetails']['followingAmount'],
              followersAmount: i['SalonShopDetails']['followersAmount'],
              shopDesciption: i['SalonShopDetails']['shopDesciption'],
              shopIconAddr: i['SalonShopDetails']['shopIconAddr'],
              shopAddr: i['SalonShopDetails']['shopAddr']
          )
      );
    });

    return currentUserFinal;
  }

  Map<String,dynamic> constructDSForDB(UserAccInfo currentUserAccInfo){
    List<dynamic> x = [];

    x.add({'SalonShopDetails':{
      'shopName': "Beauty Salon",'postsAmount': "3908",'followersAmount': "4000",'followingAmount': "2",
      'shopDesciption': "To be the best barber shop in the world\nWe have 200 branches around the world\n",
      'shopIconAddr': "assets/beautySalon.png",'shopAddr': "Merlin Building, 30-34 Cochrane St, Central"
    }
    });
    Map<String,dynamic> tmp = {
      'userInfo': {
        'userName': currentUserAccInfo.userName,
        'userEmail': currentUserAccInfo.userEmail,
        'userIconAddr': currentUserAccInfo.userIconAddr,
        'followingListIconAddr': [
          'assets/emptyAvatar.png',
          'assets/emptyAvatar.png'
        ],
        'historyListIconAddr': [
          'assets/emptyAvatar.png',
          'assets/emptyAvatar.png'
        ],
        'bookingCount': 0,
        'userAcc': '',
        'userPwd': '',
        'isLogin': 1,
        'bookingRec': [
          {'BookingDetails':{
            'branchName': "Beauty Salon",'bookingID': "00001",'serviceDescription':"Washing,Cutting and Browing",
            'moneyPaid': "USD\$200",'appointmentDate': "06/09/2020",'bookingQuantity': "1",'branchIconAddr': "assets/beautySalon.png"
          }},
          {'BookingDetails':{
            'branchName': "TIC Salon",'bookingID': "00001",'serviceDescription':"Washing,Cutting and Browing",
            'moneyPaid': "USD\$200",'appointmentDate': "06/09/2020",'bookingQuantity': "3",'branchIconAddr': "assets/salontic.jpg"
          }},
        ],
        'followingList': [
          {'SalonShopDetails':{
            'shopName': "Beauty Salon",'postsAmount': "3908",'followersAmount': "4000",'followingAmount': "2",
            'shopDesciption': "To be the best barber shop in the world\nWe have 200 branches around the world\n",
            'shopIconAddr': "assets/beautySalon.png",'shopAddr': "Merlin Building, 30-34 Cochrane St, Central"
          }
          }
        ],
        'browsingHistory': [
          {'SalonShopDetails':{
            'shopName': "Beauty Salon",'postsAmount': "3908",'followersAmount': "4000",'followingAmount': "2",
            'shopDesciption': "To be the best barber shop in the world\nWe have 200 branches around the world\n",
            'shopIconAddr': "assets/beautySalon.png",'shopAddr': "Merlin Building, 30-34 Cochrane St, Central"
          }
          }
        ],
        'newdata': x
      }
    };

  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    print("HAHAHAHAHAHAAHAH");
    UserAccInfo currentUserFinal = loadDataInDS(widget.currentUserAccInfo);





//    print(widget.currentUserAccInfo['bookingRec'][0]['BookingDetails']['branchIconAddr']);
//    print('current user name :: '+ widget.currentUserAccInfo['userName']);

//    userAccDB.forEach((acc) {
//      if(acc.userEmail == widget.userEmailMatching){
//        currentUserFinal = acc;
//      }
//    });


//    if(widget.currentUser != null){
//      currentUserFinal = widget.currentUser;
//      print(widget.currentUser.userName);
//    }else{
//      currentUserFinal = UserAccInfo(
//          userName:'',
//          userEmail:'',
//          userIconAddr: 'assets/emptyAvatar.png',
//          followingListIconAddr:[],
//          historyListIconAddr:[],
//          bookingCount: 0,
//          userAcc: '',
//          userPwd: '',
//          isLogin: 0 ,
//      );
//      print('No user login yet!');
//    }

    _children.add(Homepage(currentUserAcc: currentUserFinal,));
    _children.add(PersonalPage(userAccDB:userAccDB,currentUserInfo: currentUserFinal,));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack( // Use indexedStack to keep state of widgets which being routed by navigation bar
        index: _currentIdx,
        children: _children,
      ),
      bottomNavigationBar: BottomNavigationBar(
        showSelectedLabels: true,
        currentIndex: _currentIdx,
        type: BottomNavigationBarType.fixed,
        onTap: onTappedBar,
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Homepage'
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Mybooking'
          )
        ],
      )
    );
  }
}



