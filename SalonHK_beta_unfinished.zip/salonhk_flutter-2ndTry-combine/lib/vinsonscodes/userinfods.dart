class UserAccInfo{
  String userName = "";
  String userEmail = "";
  String userIconAddr = "";
  List<String> followingListIconAddr = [];
  List<String> historyListIconAddr = [];
  int bookingCount = 0;
  String userAcc = "";
  String userPwd = "";
  int isLogin = 1;
  List<BookingDetails> bookingRec;
  List<SalonShopDetails> followingList;
  List<SalonShopDetails> browsingHistory;


  UserAccInfo({
    this.userName,
    this.userEmail,
    this.userIconAddr,
    this.followingListIconAddr,
    this.historyListIconAddr,
    this.bookingCount,
    this.userAcc,
    this.userPwd,
    this.isLogin,
    this.bookingRec,
    this.followingList,
    this.browsingHistory
    });




}

class BookingDetails {
  BookingDetails({this.branchName,this.bookingID,this.serviceDescription,this.isExpanded = false,
    this.appointmentDate,this.bookingQuantity,this.moneyPaid,this.branchIconAddr});

  String branchName;
  String bookingID;
  String serviceDescription;
  String appointmentDate;
  String bookingQuantity;
  String moneyPaid;
  String branchIconAddr;
  bool isExpanded;
}

class SalonShopDetails{
  String shopName;
  String postsAmount;
  String followersAmount;
  String followingAmount;
  String shopDesciption;
  String shopIconAddr;
  String shopAddr;

  SalonShopDetails({
    this.shopName,
    this.postsAmount,
    this.followersAmount,
    this.followingAmount,
    this.shopDesciption,
    this.shopIconAddr,
    this.shopAddr
  });
}