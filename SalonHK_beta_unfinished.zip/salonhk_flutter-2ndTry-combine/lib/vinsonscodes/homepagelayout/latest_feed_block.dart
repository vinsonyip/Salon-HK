import 'package:flutter/material.dart';
import 'latest_feed_card.dart';

class LatestFeedBlk extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
        color: Colors.grey[300],
        child: Column(
          children: [
            Expanded(
              flex: 1,
              child: Container(
              margin: const EdgeInsets.all(2.0),
              padding: const EdgeInsets.all(5.0),
              decoration: BoxDecoration(
              borderRadius: BorderRadius.all(
              Radius.circular(20.0) //                 <--- border radius here
              ),
              color: Colors.grey[200],
              ),
              child: Row(
              children: [
              SizedBox(width: 10,),
              Text(
              'Latest Feed',
              style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.bold
              ),
              ),
              ],
              ),
              ),
            ),
            Expanded(
              flex: 9,
              child: ListView(
                children:[
                  Container(
                    height: 380,
                    child: LatestFeedCard()
                  ),
                  Container(
                      height: 380,
                      child: LatestFeedCard()
                  ),
                ]
              ),
            )
            ],
        ),
      );




  }
}




