import 'package:flutter/material.dart';

class LatestFeedCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      color:Colors.grey[300],
      child: Card(
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    CircleAvatar(
                        radius:20.0,
                        backgroundImage:AssetImage('assets/thumb.jpg')
                    ),
                    SizedBox(width: 20,),
                    Text("Fashion Dressing")
                  ],
                ),
              ),
              Text('Latest news: Our shop opens at Tomorrow!\nCome and Visit us'),
              SizedBox(height: 10,),
              Image(
                image:AssetImage(
                    'assets/thumb.jpg'
                ),
                height: 200,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Expanded(
                    flex:5,
                    child: FlatButton.icon(
                      onPressed: (){},
                      icon:Icon(Icons.favorite_border),
                      label:Text('Like')
                      ),
                    ),
                  Expanded(
                    flex:6,
                    child: FlatButton.icon(
                        onPressed: (){},
                        icon:Icon(Icons.add_comment),
                        label:Text('Comment')
                    ),
                  ),
                  Expanded(
                    flex:5,
                    child: FlatButton.icon(
                        onPressed: (){},
                        icon:Icon(Icons.share),
                        label:Text('Share')
                    ),
                  ),
                ],
              )
            ],
          ),
          ),

    );
  }
}
