import 'package:flutter/material.dart';

class SearchByTagBlk extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.grey[300],
      child:GridView.count(
        crossAxisCount: 3,
        childAspectRatio: 3,
        padding: const EdgeInsets.all(1.0),
        mainAxisSpacing: 5.0,
        crossAxisSpacing: 10.0,

        children: [
          Text("Search by Tags"),
          Text(""),
          Text(""),
        FlatButton(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10.0),
            ),
            color: Colors.blue[600],
            textColor: Colors.grey[100],
            padding: EdgeInsets.all(8.0),
            onPressed: () {},
            child: Text(
              "Male",
              style: TextStyle(
              fontSize: 14.0,
               ),
            ),
        ),
        FlatButton(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10.0),
            ),
            color: Colors.pink[200],
            textColor: Colors.grey[100],
            padding: EdgeInsets.all(8.0),
            onPressed: () {},
            child: Text(
              "Female",
              style: TextStyle(
                fontSize: 14.0,
              ),
            ),
          ),
        Text(""),
        FlatButton(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10.0),
            ),
            color: Colors.lightGreen[800],
            textColor: Colors.grey[100],
            padding: EdgeInsets.all(8.0),
            onPressed: () {},
            child: Text(
              "Hairdressing",
              style: TextStyle(
                fontSize: 14.0,
              ),
            ),
          ),
        FlatButton(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10.0),
          ),
          color: Colors.lightGreen[800],
          textColor: Colors.grey[100],
          padding: EdgeInsets.all(8.0),
          onPressed: () {},
          child: Text(
            "Shaving",
            style: TextStyle(
              fontSize: 14.0,
            ),
          ),
    ),
        FlatButton(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10.0),
            ),
            color: Colors.lightGreen[800],
            textColor: Colors.grey[100],
            padding: EdgeInsets.all(8.0),
            onPressed: () {},
            child: Text(
              "Eyebrow \ndressing",
              style: TextStyle(
                fontSize: 9.0,
              ),
            ),
          ),
        ],
      )

    );
  }
}
