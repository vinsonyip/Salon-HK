import 'package:flutter/material.dart';
import 'package:salonhk_flutter/vinsonscodes/userinfods.dart';
import 'package:salonhk_flutter/controllers/auth.dart';

class UserLogoutBlk extends StatefulWidget {

  // ignore: non_constant_identifier_names
  @override
  _UserLogoutBlkState createState() => _UserLogoutBlkState();
}

class _UserLogoutBlkState extends State<UserLogoutBlk> {
  @override
  UserAccInfo userInfoToBeCleared =
  UserAccInfo(
      userName:'',
      userEmail:'',
      userIconAddr: 'assets/emptyAvatar.png',
      followingListIconAddr:[],
      historyListIconAddr:[],
      bookingCount: 0,
      isLogin: 0
  );

  Widget build(BuildContext context) {
    return Align(
        alignment: Alignment.bottomCenter,
        child: RaisedButton(
          onPressed: () {
            Auth().signOut();
            Navigator.pushReplacementNamed(context, '/wrapper',arguments: {
              'currentUser' : userInfoToBeCleared
            });
          },
          child: const Text('Logout', style: TextStyle(fontSize: 20)),
          color: Colors.red,
          textColor: Colors.white,
          elevation: 5,
        ),
      );
  }
}




class UserLoginBlk extends StatefulWidget {
  final List<UserAccInfo> userAccDB;

  UserLoginBlk({Key key,this.userAccDB}) : super(key:key);
  @override
  _UserLoginBlkState createState() => _UserLoginBlkState();
}

class _UserLoginBlkState extends State<UserLoginBlk> {

  bool isLogin = true;


  @override
  Widget build(BuildContext context) {

    return Align(
      alignment: Alignment.bottomCenter,
      child: RaisedButton(
        onPressed: () {
          Navigator.pushNamed(context, '/loginpage',arguments: {
            'userAccDB': widget.userAccDB
          });
        },
        child: const Text('Login', style: TextStyle(fontSize: 20)),
        color: Colors.green,
        textColor: Colors.white,
        elevation: 5,
      ),
    );;
  }
}

