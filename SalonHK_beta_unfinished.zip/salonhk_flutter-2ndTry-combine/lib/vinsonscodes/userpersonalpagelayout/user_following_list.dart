import 'package:flutter/material.dart';
import 'package:salonhk_flutter/vinsonscodes/userinfods.dart';

class UserFollowBlk extends StatelessWidget {
  List<String> iconAssets = [];

//  'assets/thumb.jpg','assets/emptyAvatar.png','assets/twittericon.png'
  UserAccInfo userInfo;

  UserFollowBlk({Key key, this.userInfo}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    userInfo = (userInfo != null)
        ? userInfo
        : UserAccInfo(
            userName: '',
            userEmail: '',
            userIconAddr: '',
            followingListIconAddr: [],
            historyListIconAddr: [],
            bookingCount: 1,
            userAcc: '',
            userPwd: '',
            isLogin: 0);
    iconAssets = userInfo.followingListIconAddr;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          height: 30,
          child: Row(
            children: [
              Expanded(
                  flex: 1,
                  child: Text('Following,',
                      style: TextStyle(
                        letterSpacing: 2.0,
                      ))),
              TextButton(
                  onPressed: () {
                    Navigator.pushNamed(context, '/followingpage',
                        arguments: {'followingList': userInfo.followingList});
                  },
                  child: Text('show all'))
            ],
          ),
        ),
        SizedBox(
          height: 10,
        ),
        SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                    children: iconAssets
                        .map((image) => BarberShopIcon(
                              imageAddr: image,
                            ))
                        .toList(),
                  ),
                ])),
      ],
    );
  }
}

class BarberShopIcon extends StatelessWidget {
  String imageAddr;

  BarberShopIcon({this.imageAddr});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(0, 0, 10, 0),
      child: IconButton(
        onPressed: () {},
        icon: CircleAvatar(
            radius: 50.0, backgroundImage: AssetImage('$imageAddr')),
      ),
    );
  }
}
