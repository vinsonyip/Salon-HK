import 'package:flutter/material.dart';
import 'package:salonhk_flutter/vinsonscodes/userinfods.dart';

class UserAvatarBlk extends StatelessWidget {

  final UserAccInfo userInfo;

  String userName = ""; // Vinson Yip
  String userEmail = ""; // vinsonyip@gmail.com
  String userAvatar = ""; // assets/thumb.jpg

  UserAvatarBlk({Key key, this.userInfo}) : super(key:key);

  @override
  Widget build(BuildContext context) {
    userName = userInfo.userName;
    userEmail = userInfo.userEmail;
    userAvatar = userInfo.userIconAddr;

    return Center(
        child: Row(
          children: [
            Expanded(
              flex: 1,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                      'Hello,',
                      style: TextStyle(
                        letterSpacing: 2.0,
                      )
                  ),
                  SizedBox(height: 10.0,),
                  Text(
                      '$userName',
                      style: TextStyle(
                        letterSpacing: 2.0,
                        fontSize: 28.0,
                        fontWeight: FontWeight.bold,
                      )
                  ),
                  SizedBox(height: 10.0,),
                  Row(
                    children: [
                      Icon(
                        Icons.email,
                        color: Colors.grey[400],
                      ),
                      SizedBox(width: 10.0,),
                      Text(
                          '$userEmail',
                          style:TextStyle(
                            fontSize: 18.0,
                            letterSpacing: 1.0,
                          )
                      ),


                    ],
                  ),
                ],
              ),
            ),
            CircleAvatar(
                backgroundColor: Colors.grey[400],
                radius:40.0,
                backgroundImage:AssetImage('$userAvatar')
            ),
          ],
        ),
    );
  }
}
