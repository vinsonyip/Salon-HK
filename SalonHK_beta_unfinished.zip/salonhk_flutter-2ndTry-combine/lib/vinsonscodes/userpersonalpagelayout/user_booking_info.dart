import 'package:flutter/material.dart';
import 'package:salonhk_flutter/vinsonscodes/userinfods.dart';

class UserBookingInfoBlk extends StatelessWidget {
  final UserAccInfo userInfo;
  int bookingCount;

  UserBookingInfoBlk({Key key, this.userInfo}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    bookingCount = userInfo.bookingCount;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          height: 30,
          child: Row(
            children: [
              Expanded(
                flex: 1,
                child: Text('Your Booking,',
                    style: TextStyle(
                      letterSpacing: 2.0,
                    )),
              ),
              TextButton(
                  onPressed: () {
                    Navigator.pushNamed(context, '/bookingpage', arguments: {'bookDetails': userInfo.bookingRec});
                  },
                  child: Text('show all'))
            ],
          ),
        ),
        SizedBox(
          height: 10.0,
        ),
        Text('$bookingCount',
            style: TextStyle(
              letterSpacing: 2.0,
              fontSize: 28.0,
              fontWeight: FontWeight.bold,
            )),
      ],
    );
  }
}


