import 'package:flutter/material.dart';
import 'package:salonhk_flutter/vinsonscodes/userinfods.dart';
import 'package:salonhk_flutter/vinsonscodes/historypage.dart';

class UserHistoryBlk extends StatelessWidget {
  final UserAccInfo userInfo;

  UserHistoryBlk({Key key,this.userInfo}) : super(key:key);

  List <String> iconAssets;
  //  'assets/thumb.jpg', 'assets/thumb.jpg', 'assets/thumb.jpg', 'assets/thumb.jpg', 'assets/thumb.jpg'



  @override
  Widget build(BuildContext context) {
    iconAssets = userInfo.historyListIconAddr;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          height: 30,
          child: Row(
            children: [
              Expanded(
                flex:1,
                child: Text(
                    'History,',
                    style: TextStyle(
                      letterSpacing: 2.0,
                    )
                ),
              ),
              TextButton(onPressed: (){
                Navigator.pushNamed(context, '/historypage',arguments: {'browsingHistory':userInfo.browsingHistory});
              }, child: Text('show all'))
            ],
          ),
        ),
        SizedBox(height: 10.0,),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: iconAssets.map((imgAddr) => HistoryBrowsedBarberIcon(imageAddr: imgAddr)).toList()
          ),
        ),

      ],
    );
  }
}

class HistoryBrowsedBarberIcon extends StatelessWidget {
  String imageAddr;
  HistoryBrowsedBarberIcon({this.imageAddr});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(0, 0, 20,0),
      child: SizedBox(
        height: 70,
        width: 70,
        child: Card(
          child: Image(
            image: AssetImage(
                '$imageAddr'
            ),
          ),

        ),
      ),
    );
  }
}
