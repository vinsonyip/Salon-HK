import 'package:flutter/material.dart';
import 'userpersonalpagelayout/user_history.dart';
import 'userpersonalpagelayout/user_avatar.dart';
import 'userpersonalpagelayout/user_login_out.dart';
import 'userpersonalpagelayout/user_following_list.dart';
import 'userpersonalpagelayout/user_booking_info.dart';
import 'userinfods.dart';

class PersonalPage extends StatefulWidget {
  List<UserAccInfo> userAccDB;
  UserAccInfo currentUserInfo;

  PersonalPage({this.userAccDB, this.currentUserInfo});

  @override
  _PersonalPageState createState() => _PersonalPageState();
}

class _PersonalPageState extends State<PersonalPage> {
  List<UserAccInfo> userAccDB;

  UserAccInfo currentUserInfo = UserAccInfo(
      userName: '',
      userEmail: '',
      userIconAddr: 'assets/emptyAvatar.png',
      followingListIconAddr: [''],
      historyListIconAddr: [''],
      bookingCount: 0,
      isLogin: 0);

  int isLogin = 0; // 0 - logout state , 1 - login state

  final List<Widget> loginAndLogoutWidgets =
      []; // Login & Logout button switching

  void cleanAll(userInfo) {
    setState(() {
      currentUserInfo = userInfo;
    });
  }

  void loginPassBack() {}

  void accChecking() {}

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    userAccDB = widget.userAccDB;
    currentUserInfo = widget.currentUserInfo;
    isLogin = widget.currentUserInfo.isLogin;

    loginAndLogoutWidgets.add(UserLoginBlk(
      userAccDB: this.userAccDB,
    )); //Login button as index 0
    loginAndLogoutWidgets.add(UserLogoutBlk()); //Logout button as index 1
  }

  @override
  Widget build(BuildContext context) {
//    print(data);
    return Scaffold(
      backgroundColor: Colors.grey[300],
      appBar: AppBar(
        title: Text('My Barber Card'),
        centerTitle: true,
        backgroundColor: Colors.blueGrey[400],
        elevation: 0.0,
      ),
      body: Padding(
          padding: EdgeInsets.fromLTRB(30.0, 20.0, 30.0, 0.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                  flex: 5, child: UserAvatarBlk(userInfo: currentUserInfo)),
              Divider(
                height: 20.0,
                color: Colors.grey[800],
              ),
              Expanded(
                  flex: 4, child: UserFollowBlk(userInfo: currentUserInfo)),
              Expanded(
                  flex: 3,
                  child: UserBookingInfoBlk(userInfo: currentUserInfo)),
              Expanded(
                  flex: 5,
                  child: UserHistoryBlk(
                    userInfo: currentUserInfo,
                  )),
              loginAndLogoutWidgets[isLogin]
            ],
          )),
    );
  }
}
