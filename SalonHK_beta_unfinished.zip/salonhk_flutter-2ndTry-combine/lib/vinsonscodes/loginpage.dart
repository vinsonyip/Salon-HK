import 'package:flutter/material.dart';
import 'userinfods.dart';

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  Map data;
  List <UserAccInfo> UserVerificationList =[UserAccInfo(
      userName:'',
      userEmail:'',
      userIconAddr: '',
      followingListIconAddr:[],
      historyListIconAddr:[],
      bookingCount: 1,
      userAcc: '',
      userPwd: '',
      isLogin: 0
  )]; // The test UserInfo inside, to avoid error when debugging
  final _userNameTextfieldController = TextEditingController();
  final _userPasswordTextfieldController = TextEditingController();


  @override
  Widget build(BuildContext context) {
    data = ModalRoute.of(context).settings.arguments;
    UserVerificationList = data['userAccDB'];


    return Scaffold(
      appBar: AppBar(

      ),
      body: Container(
        decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage("assets/thumb.jpg"),
                fit: BoxFit.cover
            )
        ),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(50,80,50,0),
          child: Center(
              child: Column(
                children: [
                  Text('User Login',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 50 ,color: Colors.brown[400]),),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(0,20,0,10),
                    child: Container(
                      color: Colors.white,
                      width: 290,
                      child: TextField(
                        controller: _userNameTextfieldController,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(),
                          hintText: 'Enter User Name Here',
                        ),
                        autofocus: false,
                      ),
                    ),
                  ),
                  Container(
                    color: Colors.white,
                    width: 290,
                    child: TextField(
                      controller: _userPasswordTextfieldController,
                      decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        hintText: 'Enter Password Here',
                      ),
                      autofocus: false,
                      obscureText: true,
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                     Checkbox(value: true, onChanged: (bool x){}),
                     Text('Rememeber me'),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      FlatButton(onPressed: (){
                        setState(() { // search if acc exist
                          for(final userdata in UserVerificationList){
                            // userAcc: 'vinson123',
//                            userPwd: 'abc123'
                            if ((userdata.userAcc == _userNameTextfieldController.text)&&(userdata.userPwd == _userPasswordTextfieldController.text)){
                              print("Acc exist");
                              Navigator.pushReplacementNamed(context, '/home',arguments: {
                                'currentUser' : userdata
                              }); // If login successfully, go back to '/home'.still need to pass args
                              break;
                            }else{
                              print("Acc not exist");
                            }
                          }
//                          print("User name:"+_userNameTextfieldController.text + "\n Password: " + _userPasswordTextfieldController.text);

                        });
                        }, color:Colors.deepOrangeAccent,child: Text('Sign-in',style: TextStyle(color: Colors.white),)),
                      Text('      or'),
                      FlatButton(onPressed: (){}, child: Text('create an account',style: TextStyle(color: Colors.blueAccent,decoration: TextDecoration.underline),))
                    ],
                  ),
                  SizedBox(height: 20,),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.fromLTRB(0,0,20,0),
                        child: CircleAvatar(
                          radius:20.0,
                          backgroundColor: Colors.white,
                          child: IconButton(
                            splashColor: Colors.grey[500],
                            color: Colors.black,
                            onPressed: (){},
                            icon:Image(
                              image: AssetImage('assets/googleicon.png')
                              )
                            ),
                          ),
                      ),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(0,0,20,0),
                        child: CircleAvatar(
                          radius:20.0,
                          backgroundColor: Colors.white,
                          child: IconButton(
                              splashColor: Colors.grey[500],
                              color: Colors.black,
                              onPressed: (){},
                              icon:Image(
                                  image: AssetImage('assets/facebookicon.png')
                              )
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(0,0,20,0),
                        child: CircleAvatar(
                          radius:20.0,
                          backgroundColor: Colors.white,
                          child: IconButton(
                              splashColor: Colors.grey[500],
                              color: Colors.black,
                              onPressed: (){},
                              icon:Image(
                                  image: AssetImage('assets/twittericon.png')
                              )
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
          ),
        ),
      ),
    );
  }
}
