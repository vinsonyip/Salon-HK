import 'package:flutter/material.dart';
import 'userinfods.dart';

class BookingPage extends StatefulWidget {

  @override
  _BookingPageState createState() => _BookingPageState();
}

class _BookingPageState extends State<BookingPage> {
  Map data;
  List<BookingDetails> _item = [
//    BookingDetails(branchName: "Beauty Salon",bookingID: "00001",serviceDescription:"Washing,Cutting and Browing",
//    moneyPaid: "USD\$200",appointmentDate: "06/09/2020",bookingQuantity: "1",),
//    BookingDetails(branchName: "ABC Salon",bookingID: "00002",serviceDescription:"Washing,Cutting and Browing",
//      moneyPaid: "USD\$100",appointmentDate: "20/09/2020",bookingQuantity: "1",),
//    BookingDetails(branchName: "Prime Salon",bookingID: "00003",serviceDescription:"Facial Treatment",
//      moneyPaid: "USD\$50",appointmentDate: "07/10/2020",bookingQuantity: "1",),
  ];


  @override
  Widget build(BuildContext context) {
    data = ModalRoute.of(context).settings.arguments;
    _item  = (data['bookDetails'] != null ) ? data['bookDetails'] : [] ;

//    _item = data['bookDetails'];
    return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(backgroundColor: Colors.blueGrey[400],
        title: Text('My Booking'),),
        body:ListView(
          children: [
            ExpansionPanelList(
                animationDuration: Duration(milliseconds: 600),
                expansionCallback: (int index,bool isExpanded){
                  setState(() {
                    _item[index].isExpanded = !_item[index].isExpanded;
                  });
                },
                children:_item.map((BookingDetails item) => ExpansionPanel(
                    headerBuilder: (BuildContext context,bool isExpanded){
                      return Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Row(
                          children: [
                            Padding(
                              padding: const EdgeInsets.fromLTRB(0,0,16,0),
                              child: Image(image: AssetImage(item.branchIconAddr),height: 50,width: 50,),
                            ),
                            Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(item.branchName,style: TextStyle(fontWeight: FontWeight.bold),),
                                SizedBox(height: 5,),
                                Text('Booking No. '+item.bookingID,style: TextStyle(fontSize: 10,letterSpacing: 1),),
                                Text(item.serviceDescription,style: TextStyle(fontSize: 10,letterSpacing: 1),),
                                Text("Date:" + item.appointmentDate,style: TextStyle(fontSize: 10,letterSpacing: 1),),
                              ],
                            ),
                          ],
                        ),
                      );
                    },
                    isExpanded: item.isExpanded,
                    body: Container(
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(12,0,12,0),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Card(
                                color: Colors.blueGrey,
                                child: Container(
                                  decoration: BoxDecoration(
                                    image: DecorationImage(
                                      image: AssetImage("assets/cardbackground.jpg"),
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                  child: Center(
                                      child: Image(
                                        image: AssetImage(item.branchIconAddr??''),
                                        height: 150,
                                      )),
                                )),
                            Center(
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Column(
                                  children: [
                                    Text(
                                      'Booking ID',
                                      style: TextStyle(color: Colors.grey[500]),
                                    ),
                                    Text(
                                      item.bookingID,
                                      style: TextStyle(
                                          fontSize: 20,
                                          color: Colors.green,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Divider(),
                            Text(item.branchName,
                                style:
                                TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                            SizedBox(
                              height: 10,
                            ),
                            Text(item.serviceDescription,
                                style: TextStyle(fontSize: 12, color: Colors.grey[500])),
                            SizedBox(height: 20,),
                            Text('Appointment Date: ' + item.appointmentDate,
                                style:
                                TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                            SizedBox(
                              height: 10,
                            ),
                            Text('Quantity', style: TextStyle(fontSize: 14)),
                            SizedBox(
                              height: 10,
                            ),
                            Row(
                              children: [
                                Icon(Icons.confirmation_number),
                                SizedBox(
                                  width: 10,
                                ),
                                Text(
                                  item.bookingQuantity,
                                  style: TextStyle(
                                      fontSize: 20,
                                      color: Colors.green,
                                      fontWeight: FontWeight.bold),
                                )
                              ],
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Text('Totally Paid: ',
                                    style:
                                    TextStyle(fontSize: 12, color: Colors.grey[500])),
                                Text(item.moneyPaid,
                                    style: TextStyle(fontSize: 20, color: Colors.red)),
                              ],
                            ),
                            Divider(),
                            Container(
                              height: 80,
                              width: 500,
                              child: Padding(
                                padding: const EdgeInsets.fromLTRB(8,8,8,14),
                                child: FittedBox(
                                  child: Image.asset('assets/barcodesample.png'),
                                  fit: BoxFit.fitWidth,
                                ),
                              ),
                            )

                          ],
                        ),
                      ),
                    )
                )
                ).toList()
            )
          ],
        ),

    );
  }
}



