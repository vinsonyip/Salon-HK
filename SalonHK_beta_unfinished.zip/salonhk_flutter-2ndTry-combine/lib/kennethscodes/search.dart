import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:salonhk_flutter/kennethscodes/shop_details.dart';
import 'dart:async';
//import 'package:flappy_search_bar/flappy_search_bar.dart';

class HomePage extends StatefulWidget {
  final List<String> list = List.generate(10, (index) => "Salon $index");
  final List<String> shopNameList = ["Emmanuel Hair", "Voi Voi Rakkaus Hair Salon", "Suyan Beauty "];
  final List<String> addressList =["36 Pok Fu Lam Rd, Sai Wan", "10/F, The Loop, 33 Wellington St, Central", "Flat B2, 5/F., Cheung Fat Industrial Building, 7-9 Hill Road, Sai Wan, Sai Ying Pun"];
  final List<String> imageList = ["assets/images/Emmanuel.jpg","assets/images/VoiVoi.jpg", "assets/images/Suyan.jpg"];
  final List<String> script = ["This is the descrption of Emmanuel", "This is the descrption of Voi Voi Rakkaus Hair Salon", "This is the descrption of Suyan Beauty"];

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with SingleTickerProviderStateMixin{
  final TextEditingController _filter = new TextEditingController();
  String _searchText = "";
  List names = new List(); // names we get from API
  List filteredNames = new List(); // names filtered by search text
  final List<String> pageNameList = ["Home Page", "List Page", "Message Page"];
  String currentTitle;
  TabController _tcontroller;

  @override
  void initState() {
    currentTitle = pageNameList[0];
    _tcontroller = TabController(length: 3, vsync: this);
    _tcontroller.addListener(changeTitle); // Registering listener
    super.initState();
  }

  void changeTitle() {
    setState(() {
      // get index of active tab & change current appbar title
      currentTitle = pageNameList[_tcontroller.index];
    });
  }
  Widget buildBody(BuildContext context, int index) {
    return new Text(widget.shopNameList[index]);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
//        leading:
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(),
        ),
        centerTitle: true,
        title: Container(
          margin: EdgeInsets.symmetric(horizontal: 0.0,vertical: 8.0),
          decoration: BoxDecoration(
              color:Color.fromARGB(50, 255, 255, 255),
              borderRadius: BorderRadius.all(Radius.circular(22.0))
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                flex: 1,
                child: FlatButton(
                    onPressed: (){
                      showSearch(context: context,
                          delegate: Search(
                              recentList:widget.shopNameList,shopNameList:widget.shopNameList,
                              listExample: widget.shopNameList,addressList: widget.addressList,
                              imageList:widget.imageList,script: widget.script));
                    },
                    child: Text(
                        'Search Bar'
                    )),
              )
            ],
          ),
        ),
      ),
      body: new ListView.builder(
        
        itemCount: widget.shopNameList.length,

        itemBuilder: (context, index) => Card(
            semanticContainer: true,
          clipBehavior: Clip.antiAlias,

          child: CupertinoButton(
              //crossAxisAlignment: CrossAxisAlignment.start,
            child:Container(
              height: 180,
              //width: 200,
              decoration: BoxDecoration(
                image: DecorationImage(
                    image: AssetImage("${widget.imageList[index] }"),
                    fit: BoxFit.cover,
                ),
                borderRadius: BorderRadius.circular(12),
              ),

                child: Container(
                  //height: 50,
                  //margin: EdgeInsets.all(20.0),
                  //color: Colors.orange,
                  decoration: new BoxDecoration(

                  ),
                  child: new ListTile(

                    onTap: (){
                      print("tapped");
                      Navigator.push(context, MaterialPageRoute(
                        builder: (context)=>SalonPage(index: widget.shopNameList[index], address: widget.addressList[index], path:widget.imageList[index],script: widget.script[index]),
                      )
                      );

                    },
                    //leading: FlutterLogo(),

                    title: Text(
                      widget.shopNameList[index],

                      style: TextStyle(
                        //backgroundColor: Colors.blue,
                        background:
                        Paint()
                          ..strokeWidth = 25.0
                          ..style = PaintingStyle.stroke
                          ..strokeJoin = StrokeJoin.round
                          ..color = Color.fromRGBO(255, 255, 255, 0.5),

                        color: Colors.black,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                )

                //child: Image.asset('assets/images/${widget.ImageList[index]}.jpg')


            )
            )
              //bordeRadius: BorderRadius.circular(20)



        ),
      ),
    );
  }

}

class Search extends SearchDelegate {

  List<String> recentList;
  List<String> shopNameList;
  List<String> addressList;
  List<String> imageList;
  List<String> script;

  final List<String> listExample;
  Search({this.listExample,this.recentList,this.shopNameList,this.addressList,this.imageList,this.script});



  @override
  List<Widget> buildActions(BuildContext context) {
    return <Widget>[
      IconButton(
        icon: Icon(Icons.close),
        onPressed: () {
          query = "";
        },
      ),
    ];
  }

  @override
  Widget buildLeading(BuildContext context) {
    return IconButton(
      icon: Icon(Icons.arrow_back),
      onPressed: () {
        Navigator.pop(context);
      },
    );
  }

  String selectedResult = "";

  @override
  Widget buildResults(BuildContext context) {
    return Container(
      child: Center(
        child: Text(selectedResult),

      ),
    );
  } // Seems useless

  @override
  Widget buildSuggestions(BuildContext context) {
    List<String> suggestionList = [];
    query.isEmpty
        ? suggestionList = recentList //In the true case
        : suggestionList.addAll(listExample.where(
      // In the false case
          (element) => element.contains(query),
    ));
/*
    return ListView.builder(
      itemCount: suggestionList.length,
      itemBuilder: (context, index) {
        return ListTile(
          title: Text(
            suggestionList[index],
          ),
          leading: query.isEmpty ? Icon(Icons.access_time) : SizedBox(),
          onTap: (){
            selectedResult = suggestionList[index];
            showResults(context);
          },
        );
      },
    );
*/

    return ListView.builder(

        itemCount: suggestionList.length,
      itemBuilder: (context, index) => Card(
        clipBehavior: Clip.antiAlias,
        child: Column(
          children: <Widget>[
            ListTile(
              onTap: (){

                //selectedResult = suggestionList[index];
                //showResults(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => SalonPage(index: shopNameList[index], address: addressList[index], path:imageList[index],script: script[index])),
                );
              },
              //leading: Image.asset('assets/images/lake.jpg'),
              title: Text(
                suggestionList[index],
              ),
            ),
            //Image.asset('assets/images/lake.jpg')
          ],
        )


      ),
    );

  }
}
