import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'search.dart';
import 'package:search_widget/search_widget.dart';

void main() {
  runApp(SearchingPage());
}

class SearchingPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: HomePage() ,
//      debugShowCheckedModeBanner: false,
//      title: 'Flutter Demo',
//      theme: ThemeData(
//        primarySwatch: Colors.blue,
//        visualDensity: VisualDensity.adaptivePlatformDensity,
//      ),
//      home: ,
    );
  }
}