import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:salonhk_flutter/kennethscodes//main.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:maps_launcher/maps_launcher.dart';


class Company{
  int id;
  String name;

}
class SalonPage extends StatelessWidget {
  //final int index;
  String index; // This is shop name
  String address;
  String path;
  String script;
  String date;
  String service;

  SalonPage({this.index, this.address, this.path, this.script});





  @override
  Widget build(BuildContext context) {

    Widget titleSection = Container(
      padding: const EdgeInsets.all(32),
      child: Row(
        children: [
          Expanded(
            /*1*/
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                /*2*/
                Container(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Text(
                    //'Sai Wan Salon',
                    this.index,
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Text(
                  this.address ?? "",
                  style: TextStyle(
                    color: Colors.grey[500],
                  ),
                ),
              ],
            ),
          ),
          /*3*/
          Icon(
            Icons.star,
            color: Colors.red[500],
          ),
          Text('41'),
        ],
      ),
    );

    Color color = Theme.of(context).primaryColor;

    Widget buttonSection = Container(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          //_buildButtonColumn(color, Icons.call, 'CALL'),
          //_buildButtonColumn(color, Icons.near_me, 'ROUTE'),
          //_buildButtonColumn(color, Icons.share, 'SHARE'),

          Column( //CALL BUTTON
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              new IconButton(
                onPressed: () => launch("tel://21213123123"),
                icon: new Icon(Icons.call, color: color,),
              ),
              Container(
                margin: const EdgeInsets.only(top: 8),
                child: Text(
                  "CALL",
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w400,
                    color: color,
                  ),
                ),
              ),
            ],
          ),

          Column( //RouteBUTTON
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              IconButton(
                onPressed: () => MapsLauncher.launchQuery(address),
                icon: Icon(Icons.near_me, color: color,),
              ),
              Container(
                margin: const EdgeInsets.only(top: 8),
                child: Text(
                  "ROUTE",
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w400,
                    color: color,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );

    Widget confirmBooking = Container(
      padding: const EdgeInsets.all(32),
      child: RaisedButton(
        child: Text('Confirm Booking'),
        onPressed:(){
          Future<void> _showMyDialog() async {


            return showDialog<void>(
              context: context,
              barrierDismissible: false, // user must tap button!
              builder: (BuildContext context) {
                return AlertDialog(
                  title: Text('AlertDialog Title'),
                  content: SingleChildScrollView(
                    child: ListBody(
                      children: <Widget>[
                        Text('This is an alert dialog.'),
                        Text('Would you like to confirm the booking?'),
                        Text(""),
                        Text(""),
                      ],
                    ),
                  ),
                  actions: <Widget>[
                    TextButton(
                      child: Text('Yes'),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                    ),
                    TextButton(
                      child: Text('Cancel'),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                    ),
                  ],
                );
              },
            );
          }

        }
      )
    );

    Widget textSection = Container(
      padding: const EdgeInsets.all(32),
      child: Text(
        this.script,
        softWrap: true,
      ),
    );

    Widget bookSection = Container(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          //var resultsList = new List.filled(3, '');
          new DropdownButton<String>(
            items: <String>['Today', '26/11', '27/11', '28/11'].map((String value) {
              return new DropdownMenuItem<String>(
                value: value,
                child: new Text(value),
              );
            }).toList(),
            onChanged: (value) {

            },
          ),
          new DropdownButton<String>(
            items: <String>['12:30pm', '1:00pm', '1:30pm', '2:00pm'].map((String value) {
              return new DropdownMenuItem<String>(
                value: value,
                child: new Text(value),
              );
            }).toList(),
            onChanged: (_) {
              //service = value;
            },
          ),
          //_buildButtonColumn(color, Icons.share, 'SHARE'),
          new DropdownButton<String>(
            items: <String>['Hair Washing', 'Hair Cut', 'Hair coloring', 'Other hair styling'].map((String value) {
              return new DropdownMenuItem<String>(
                value: value,
                child: new Text(value),
              );
            }).toList(),
            onChanged: (value) {
               service = value;
            },
          ),


        ],
      ),
    );

    return Scaffold(
        appBar: AppBar(
          title: Text('Back To Search'),
          leading: IconButton(

            icon: Icon(Icons.arrow_back_rounded),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
        ),
        body: ListView(
          children: [
            Image.asset(
              '${this.path}',
              width: 600,
              height: 240,
              fit: BoxFit.cover,
            ),
            titleSection,
            buttonSection,
            textSection,
            //bookSection,

            confirmBooking,
          ],

        ),
      );

  }

  Column _buildButtonColumn(Color color, IconData icon, String label) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        IconButton(
          onPressed: () {
            if(label == 'CALL'){
              launch("tel://21213123123");
            }
            else
              MapsLauncher.launchQuery('1600 Amphitheatre Pkwy, Mountain View, CA 94043, USA');
          },
          icon: Icon(icon, color: color,),
            ),
        Container(
          margin: const EdgeInsets.only(top: 8),
          child: Text(
            label,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w400,
              color: color,
            ),
          ),
        ),
      ],
    );
  }


}


