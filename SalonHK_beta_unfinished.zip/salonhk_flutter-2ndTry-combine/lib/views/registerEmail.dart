import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:salonhk_flutter/vinsonscodes/userinfods.dart';

import '../controllers/auth.dart';
import '../controllers/store.dart';

class RegisterEmailPage extends StatefulWidget {
  @override
  _RegisterEmailPageState createState() => _RegisterEmailPageState();
}

class _RegisterEmailPageState extends State<RegisterEmailPage> {
  final _formKey = GlobalKey<FormState>();
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController =
      TextEditingController();
  final TextEditingController _userNameController = TextEditingController();
  final TextEditingController _phoneNumberController = TextEditingController();
  final TextEditingController _nameController = TextEditingController();
  bool _isLoading = false;
  bool _obscurePassword = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      key: _scaffoldKey,
      appBar: AppBar(
        title: Text('Register'),
      ),
      body: Form(
          key: _formKey,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 50),
            child: Column(children: [
              ...[
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Text('Registration', style: TextStyle(fontSize: 25)),
                ),
                TextFormField(
                  controller: _nameController,
                  validator: (input) {
                    if (input.isEmpty) {
                      return 'Please enter your Name';
                    }
                    return null;
                  },
                  decoration: InputDecoration(
                    icon: Icon(Icons.face),
                    hintText: 'Enter your Name',
                    labelText: 'Name',
                  ),
                ),
                TextFormField(
                  controller: _userNameController,
                  validator: (input) {
                    if (input.isEmpty) {
                      return 'Please enter your Username';
                    }
                    return null;
                  },
                  decoration: InputDecoration(
                    icon: Icon(Icons.local_florist),
                    hintText: 'Enter username',
                    labelText: 'Username',
                  ),
                ),
                TextFormField(
                  controller: _phoneNumberController,
                  validator: (input) {
                    if (input.isEmpty) {
                      return 'Please enter your Phone Number';
                    }
                    if (!RegExp(r"^[569]{1}[0-9]{7}$").hasMatch(input)) {
                      return 'Invalid mobile phone number';
                    }
                    return null;
                  },
                  decoration: InputDecoration(
                    icon: Icon(Icons.local_phone),
                    hintText: 'Enter Phone Number',
                    labelText: 'Phone Number',
                  ),
                  keyboardType: TextInputType.number,
                  inputFormatters: <TextInputFormatter>[
                    FilteringTextInputFormatter.digitsOnly
                  ],
                ),
                TextFormField(
                  controller: _emailController,
                  inputFormatters: [
                    FilteringTextInputFormatter.allow(RegExp("[a-zA-Z0-9._@]")),
                  ],
                  validator: (input) {
                    if (input.isEmpty) {
                      return 'Please enter your email';
                    }
                    if (!RegExp(r"^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$")
                        .hasMatch(input)) {
                      return 'Invalid email format';
                    }
                    return null;
                  },
                  decoration: InputDecoration(
                    icon: Icon(Icons.account_circle),
                    hintText: 'Enter your email',
                    labelText: 'Email',
                  ),
                ),
                TextFormField(
                  controller: _passwordController,
                  validator: (input) {
                    if (input.isEmpty) {
                      return 'Please enter your password';
                    }
                    return null;
                  },
                  decoration: InputDecoration(
                    icon: Icon(Icons.vpn_key),
                    suffixIcon: IconButton(
                        icon: Icon(_obscurePassword
                            ? Icons.visibility
                            : Icons.visibility_off),
                        onPressed: () => setState(
                            () => {_obscurePassword = !_obscurePassword})),
                    hintText: 'Enter your password',
                    labelText: 'Password',
                  ),
                  obscureText: _obscurePassword,
                ),
                TextFormField(
                  controller: _confirmPasswordController,
                  validator: (input) {
                    if (input.isEmpty) {
                      return 'Please confirm your password';
                    }
                    if (input != _passwordController.text) {
                      return 'Password not match';
                    }
                    return null;
                  },
                  decoration: InputDecoration(
                    icon: Icon(Icons.check_circle),
                    hintText: 'Confirm your password',
                    labelText: 'Confirm Password',
                  ),
                  obscureText: true,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: ElevatedButton.icon(
                    icon: Icon(Icons.east),
                    onPressed: (){
                      if(_isLoading){
                        return null;
                      }else{
                        register();
                      }
                    },

                    label: Text('Register'),
                  ),
                ),
              ]
            ]),
          )),
    );
  }

  void register() async {
    setState(() => _isLoading = true);
    if (_formKey.currentState.validate()) {
      try {
        UserCredential userCredential = await Auth()
            .createUserWithEmailAndPassword(
                _emailController.text, _passwordController.text);
        await Store().createUser(userCredential.user.uid, {
          'email': _emailController.text,
          'phoneNumber': _phoneNumberController.text,
          'userName': _userNameController.text,
          'name': _nameController.text,
          'createdAt': new DateTime.now(),
          'uid': userCredential.user.uid,
          'userInfo': {
            'userName': _userNameController.text,
            'userEmail':_emailController.text,
            'userIconAddr': 'assets/lilyAvatar.png',
            'followingListIconAddr': [
//              'assets/beautySalon.png','assets/salontic.jpg'
            ],
            'historyListIconAddr': [
//              'assets/beautySalon.png',"assets/abcSalon.jpg","assets/primeSalon.png", 'assets/salontic.jpg','assets/lovehairSalon.png'
            ],
            'bookingCount': 0,
            'userAcc': '',
            'userPwd': '',
            'isLogin': 1,
            'bookingRec': [
//              {'BookingDetails':{
//                'branchName': "Beauty Salon",'bookingID': "00001",'serviceDescription':"Washing,Cutting and Browing",
//                'moneyPaid': "USD\$200",'appointmentDate': "06/09/2020",'bookingQuantity': "1",'branchIconAddr': "assets/beautySalon.png"
//              }},
//              {'BookingDetails':{
//                'branchName': "TIC Salon",'bookingID': "00002",'serviceDescription':"Washing,Cutting and Browing",
//                'moneyPaid': "USD\$100",'appointmentDate': "20/09/2020",'bookingQuantity': "1",'branchIconAddr': "assets/salontic.jpg"
//              }},
            ],
            'followingList': [
//              {'SalonShopDetails':{
//                'shopName': "Beauty Salon",'postsAmount': "3908",'followersAmount': "4000",'followingAmount': "2",
//                'shopDesciption': "To be the best barber shop in the world\nWe have 200 branches around the world\n",
//                'shopIconAddr': "assets/beautySalon.png",'shopAddr': "Merlin Building, 30-34 Cochrane St, Central"
//              }
//              },
//              {'SalonShopDetails':{
//                'shopName': "TIC Salon",'postsAmount': "6501",'followersAmount': "10k",'followingAmount': "10",
//                'shopDesciption': "TIC Salon has the best salon team\n We have served amount 10k people per day\n...",
//                'shopIconAddr': "assets/salontic.jpg",'shopAddr': '827, 1 Matheson St, Causeway Bay'
//              }
//              }
            ],
            'browsingHistory': [
//              {'SalonShopDetails':{
//                'shopName': "TIC Salon",'postsAmount': "6501",'followersAmount': "10k",'followingAmount': "10",
//                'shopDesciption': "TIC Salon has the best salon team\n We have served amount 10k people per day\n...",
//                'shopIconAddr': "assets/salontic.jpg",'shopAddr': '827, 1 Matheson St, Causeway Bay'
//              }
//              },
//              {'SalonShopDetails':{
//              'shopName': "Love Hair Salon",'postsAmount': "3312",'followersAmount': "100k",'followingAmount': "5",
//              'shopDesciption': "Love Hair Salon located in Central Hong Kong\n Giving you a luxury hairstyling experience\n...",
//              'shopIconAddr': "assets/lovehairSalon.png",'shopAddr': '99F Wellington St, Central'
//              }
//              },
//              {'SalonShopDetails':{
//                'shopName': "Beauty Salon",'postsAmount': "3908",'followersAmount': "4000",'followingAmount': "2",
//                'shopDesciption': "To be the best barber shop in the world\nWe have 200 branches around the world\n",
//                'shopIconAddr': "assets/beautySalon.png"
//                  }
//              },
//              {'SalonShopDetails':{
//                'shopName': "ABC Salon",'postsAmount': "1000",'followersAmount': "10K",'followingAmount': "13",
//                'shopDesciption': "ABC Salon give you a perfect hairstyle \nWe have 120 branches around the world\n",
//                'shopIconAddr': "assets/abcSalon.jpg"
//              }
//              },
//              {'SalonShopDetails':{
//                'shopName': "Prime Salon",'postsAmount': "2111",'followersAmount': "32K",'followingAmount': "37",
//                'shopDesciption': "Prime Salon offer you a good experience\nWe have 64 branches around the world\n",
//                'shopIconAddr': "assets/primeSalon.png"
//              }
//              }
            ]
          }
        });
        _scaffoldKey.currentState
            .showSnackBar(SnackBar(content: Text('Registered!')));
        //TODO: Logic after register (same as login)
      } on FirebaseAuthException catch (e) {
        if (e.code == 'weak-password') {
          _scaffoldKey.currentState.showSnackBar(
              SnackBar(content: Text('The password provided is too weak.')));
        } else if (e.code == 'email-already-in-use') {
          _scaffoldKey.currentState.showSnackBar(SnackBar(
              content: Text('The account already exists for that email.')));
        } else {
          _scaffoldKey.currentState.showSnackBar(SnackBar(
              content: Text('Something went wrong, please try again.')));
        }
      }
    }
    setState(() => _isLoading = false);
  }
}
