import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:salonhk_flutter/controllers/auth.dart';
import 'package:salonhk_flutter/models/user.dart';
import 'package:salonhk_flutter/views/user_tile.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:salonhk_flutter/controllers/database.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class UserList extends StatefulWidget {
  @override
  _UserListState createState() => _UserListState();
}

class _UserListState extends State<UserList> {
  String _currentUser;
  @override
  Widget build(BuildContext context) {
    final users = Provider.of<List<MyUserInfo>>(context) ?? [];
    users.forEach((i) {
      if(i.uid == FirebaseAuth.instance.currentUser.uid){
          _currentUser = i.name;
      }
    });

    return Column(
      children: [
        Container(child: Text(_currentUser??""),),
        FlatButton(onPressed: (){
          List<dynamic> x = [];

          x.add({'SalonShopDetails':{
            'shopName': "Beauty Salon",'postsAmount': "3908",'followersAmount': "4000",'followingAmount': "2",
            'shopDesciption': "To be the best barber shop in the world\nWe have 200 branches around the world\n",
            'shopIconAddr': "assets/beautySalon.png",'shopAddr': "Merlin Building, 30-34 Cochrane St, Central"
          }
          });

          Map<String,dynamic> tmp = {
            'userInfo': {
              'userName': 'vinson',
              'userEmail': 'vinson',
              'userIconAddr': 'assets/emptyAvatar.png',
              'followingListIconAddr': [
                'assets/emptyAvatar.png',
                'assets/emptyAvatar.png'
              ],
              'historyListIconAddr': [
                'assets/emptyAvatar.png',
                'assets/emptyAvatar.png'
              ],
              'bookingCount': 0,
              'userAcc': '',
              'userPwd': '',
              'isLogin': 1,
              'bookingRec': [
                {'BookingDetails':{
                  'branchName': "Beauty Salon",'bookingID': "00001",'serviceDescription':"Washing,Cutting and Browing",
                  'moneyPaid': "USD\$200",'appointmentDate': "06/09/2020",'bookingQuantity': "1",'branchIconAddr': "assets/beautySalon.png"
                }},
                {'BookingDetails':{
                  'branchName': "TIC Salon",'bookingID': "00001",'serviceDescription':"Washing,Cutting and Browing",
                  'moneyPaid': "USD\$200",'appointmentDate': "06/09/2020",'bookingQuantity': "3",'branchIconAddr': "assets/salontic.jpg"
                }},
              ],
              'followingList': [
                {'SalonShopDetails':{
                  'shopName': "Beauty Salon",'postsAmount': "3908",'followersAmount': "4000",'followingAmount': "2",
                  'shopDesciption': "To be the best barber shop in the world\nWe have 200 branches around the world\n",
                  'shopIconAddr': "assets/beautySalon.png",'shopAddr': "Merlin Building, 30-34 Cochrane St, Central"
                }
                }
              ],
              'browsingHistory': [
                {'SalonShopDetails':{
                  'shopName': "Beauty Salon",'postsAmount': "3908",'followersAmount': "4000",'followingAmount': "2",
                  'shopDesciption': "To be the best barber shop in the world\nWe have 200 branches around the world\n",
                  'shopIconAddr': "assets/beautySalon.png",'shopAddr': "Merlin Building, 30-34 Cochrane St, Central"
                }
                }
              ],
              'newdata': x
            }
          };

          DatabaseService(uid:FirebaseAuth.instance.currentUser.uid).updateUserData(FirebaseAuth.instance.currentUser.uid,tmp
          );
          print(FirebaseAuth.instance.currentUser.uid);
//            DatabaseService

          }, child: Text('Click me to add data'))
      ],
    );
//    return ListView.builder(
//        itemCount: users.length,
//        itemBuilder: (context,index){
//          return UserTile(userInfo: users[index],);
//        }
//    );
  }
}
//FieldValue.arrayUnion(['654sqawdaw'])