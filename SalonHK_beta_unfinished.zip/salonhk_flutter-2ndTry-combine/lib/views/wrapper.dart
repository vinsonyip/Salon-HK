import 'package:flutter/material.dart';
import 'package:salonhk_flutter/controllers/database.dart';
import 'package:salonhk_flutter/models/user.dart';
import 'package:provider/provider.dart';
import 'package:salonhk_flutter/views/home.dart';
import 'package:salonhk_flutter/views/login.dart';
import 'package:salonhk_flutter/vinsonscodes/loadingpage.dart';
import 'package:salonhk_flutter/vinsonscodes/main.dart';
import 'package:salonhk_flutter/controllers/database.dart';

class Wrapper extends StatelessWidget {
  @override
  Widget build(BuildContext context) {

    final user = Provider.of<MyUser>(context);
    if(user == null){
      return LoginPage();
    }else{
        return StreamProvider<List<MyUserInfo>>.value(
            value: DatabaseService().users,
            child: Loading()
        );


//    return Home();
    }
  }
}
