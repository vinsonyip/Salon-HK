import 'package:flutter/material.dart';
import 'package:salonhk_flutter/controllers/auth.dart';
import 'package:salonhk_flutter/models/user.dart';
import 'package:provider/provider.dart';
import 'package:salonhk_flutter/controllers/database.dart';
import 'package:salonhk_flutter/views/user_list.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final Auth _auth = Auth();

  @override
  Widget build(BuildContext context) {

//    final users = Provider.of<List<UserInfo>>(context) ?? [];

    return StreamProvider<List<MyUserInfo>>.value(
      value: DatabaseService().users,
      child: Container(
        child: Scaffold(
          appBar: AppBar(
            title: Text('Home page'),
            actions: [
              FlatButton.icon(
                icon: Icon(Icons.person),
                label: Text('Logout'),
                onPressed: ()async{
                  await _auth.signOut();
                },
              ),
            ],
          ),
        body:UserList(),
          )
        ),
      );
  }
}
