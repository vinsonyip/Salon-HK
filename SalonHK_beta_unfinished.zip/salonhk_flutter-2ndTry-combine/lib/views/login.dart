import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_facebook_auth/flutter_facebook_auth.dart';
import 'package:flutter_signin_button/flutter_signin_button.dart';

import '../controllers/auth.dart';
import '../controllers/store.dart';
import 'registerEmail.dart';
import 'registerPhone.dart';

class LoginPage extends StatefulWidget {
  LoginPage({Key key, this.title}) : super(key: key);
  final String title;

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _formKey = GlobalKey<FormState>();
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  bool _isLoading = false;
  bool _obscurePassword = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      key: _scaffoldKey,
      appBar: AppBar(
        title: Text('Login to SalonHK'),
      ),
      body: Form(
          key: _formKey,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 50),
            child: Column(children: [
              ...[
                Icon(Icons.content_cut, color: Colors.pinkAccent, size: 100.0),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child:
                      Text('Login to SalonHK', style: TextStyle(fontSize: 25)),
                ),
                TextFormField(
                  controller: _emailController,
                  inputFormatters: [
                    FilteringTextInputFormatter.allow(RegExp("[a-zA-Z0-9._@]")),
                  ],
                  validator: (input) {
                    if (input.isEmpty) {
                      return 'Please enter your email';
                    }
                    if (!RegExp(r"^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$")
                        .hasMatch(input)) {
                      return 'Invalid email format';
                    }
                    return null;
                  },
                  decoration: InputDecoration(
                    icon: Icon(Icons.account_circle),
                    hintText: 'Enter your email',
                    labelText: 'Email',
                  ),
                ),
                TextFormField(
                  controller: _passwordController,
                  validator: (input) {
                    if (input.isEmpty) {
                      return 'Please enter your password';
                    }
                    return null;
                  },
                  decoration: InputDecoration(
                    icon: Icon(Icons.vpn_key),
                    suffixIcon: IconButton(
                        icon: Icon(_obscurePassword
                            ? Icons.visibility
                            : Icons.visibility_off),
                        onPressed: () => setState(
                            () => {_obscurePassword = !_obscurePassword})),
                    hintText: 'Enter your password',
                    labelText: 'Password',
                  ),
                  obscureText: _obscurePassword,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: ElevatedButton.icon(
                    icon: Icon(Icons.login),
                    onPressed: _isLoading ? null : () => login(),
                    label: Text('Login'),
                  ),
                ),
                SignInButton(
                  Buttons.Google,
                  onPressed: () => googleSignIn(),
                ),
                SignInButton(
                  Buttons.Facebook,
                  onPressed: () => facebookSignIn(),
                ),
                ElevatedButton.icon(
                  icon: Icon(Icons.email),
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => RegisterEmailPage()),
                  ),
                  label: Text('Register with E-mail'),
                ),
                ElevatedButton.icon(
                  icon: Icon(Icons.phone),
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => RegisterPhonePage()),
                  ),
                  label: Text('Register with Phone'),
                ),
              ]
            ]),
          )),
    );
  }

  void login() async {
    setState(() => _isLoading = true);
    if (_formKey.currentState.validate()) {
      try {
        UserCredential userCredential = await Auth().signInWithEmailAndPassword(
            _emailController.text, _passwordController.text);
        //TODO: Logic after login
        _scaffoldKey.currentState
            .showSnackBar(SnackBar(content: Text('Logged in!')));
      } on FirebaseAuthException catch (e) {
        if (e.code == 'user-not-found') {
          _scaffoldKey.currentState.showSnackBar(
              SnackBar(content: Text('No user found for that email.')));
        } else if (e.code == 'wrong-password') {
          _scaffoldKey.currentState.showSnackBar(SnackBar(
              content: Text('Wrong password provided for that user.')));
        } else {
          _scaffoldKey.currentState.showSnackBar(SnackBar(
              content: Text('Something went wrong, please try again.')));
        }
      }
    }
    setState(() => _isLoading = false);
  }

  void googleSignIn() async {
    try {
      UserCredential userCredential = await Auth().signInWithGoogle();
      if (await Store().getUser(userCredential.user.uid) == null) {
        Store().createUser(userCredential.user.uid, {
          'email': userCredential.user.email,
          'phoneNumber': userCredential.user.phoneNumber,
          'name': userCredential.user.displayName,
          'createdAt': new DateTime.now()
        });
      }
      _scaffoldKey.currentState
          .showSnackBar(SnackBar(content: Text('Signed in!')));
    } catch (e) {
      _scaffoldKey.currentState.showSnackBar(
          SnackBar(content: Text('Something went wrong, please try again.')));
    }
  }

  void facebookSignIn() async {
    try {
      UserCredential userCredential = await Auth().signInWithFacebook();
      if (await Store().getUser(userCredential.user.uid) == null) {
        Store().createUser(userCredential.user.uid, {
          'email': userCredential.user.email,
          'phoneNumber': userCredential.user.phoneNumber,
          'name': userCredential.user.displayName,
          'createdAt': new DateTime.now()
        });
      }
      _scaffoldKey.currentState
          .showSnackBar(SnackBar(content: Text('Signed in!')));
    } on FacebookAuthException catch (e) {
      switch (e.errorCode) {
        case FacebookAuthErrorCode.OPERATION_IN_PROGRESS:
          _scaffoldKey.currentState.showSnackBar(SnackBar(
              content: Text(
                  'You have a previous login operation in progress, please try again.')));
          break;
        case FacebookAuthErrorCode.CANCELLED:
          _scaffoldKey.currentState.showSnackBar(
              SnackBar(content: Text('Login cancelled, please try again.')));
          break;
        case FacebookAuthErrorCode.FAILED:
          _scaffoldKey.currentState.showSnackBar(
              SnackBar(content: Text('Login failed, please try again.')));
          break;
        default:
          _scaffoldKey.currentState.showSnackBar(SnackBar(
              content: Text('Something went wrong, please try again.')));
      }
    }
  }
}
