import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:pin_code_fields/pin_code_fields.dart';

import '../controllers/auth.dart';
import '../controllers/store.dart';

class RegisterPhonePage extends StatefulWidget {
  @override
  _RegisterPhonePageState createState() => _RegisterPhonePageState();
}

class _RegisterPhonePageState extends State<RegisterPhonePage> {
  final _formKey = GlobalKey<FormState>();
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  final TextEditingController _phoneNumberController = TextEditingController();
  final TextEditingController _smsCodeController = TextEditingController();
  bool _isLoading = false;
  int _resendToken;
  String _verificationId;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      key: _scaffoldKey,
      appBar: AppBar(
        title: Text('Register'),
      ),
      body: Form(
          key: _formKey,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 50),
            child: Column(children: [
              ...[
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Text('Registration', style: TextStyle(fontSize: 25)),
                ),
                TextFormField(
                  controller: _phoneNumberController,
                  validator: (input) {
                    if (input.isEmpty) {
                      return 'Please enter your Phone Number';
                    }
                    if (!RegExp(r"^[569]{1}[0-9]{7}$").hasMatch(input)) {
                      return 'Invalid mobile phone number';
                    }
                    return null;
                  },
                  decoration: InputDecoration(
                    icon: Icon(Icons.local_phone),
                    hintText: 'Enter Phone Number',
                    labelText: 'Phone Number',
                  ),
                  keyboardType: TextInputType.number,
                  inputFormatters: <TextInputFormatter>[
                    FilteringTextInputFormatter.digitsOnly
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: ElevatedButton.icon(
                    icon: Icon(Icons.message),
                    onPressed: _isLoading ? null : () => send(),
                    label: _verificationId == null
                        ? Text('Send verification code')
                        : Text('Resend verification code'),
                  ),
                ),
                PinCodeTextField(
                  enabled: _verificationId == null ? false : true,
                  appContext: context,
                  pastedTextStyle: TextStyle(
                    color: Colors.green.shade600,
                    fontWeight: FontWeight.bold,
                  ),
                  length: 6,
                  obscureText: false,
                  animationType: AnimationType.fade,
                  validator: (v) {
                    return null;
                  },
                  pinTheme: PinTheme(
                      shape: PinCodeFieldShape.box,
                      borderRadius: BorderRadius.circular(5),
                      fieldHeight: 50,
                      fieldWidth: 30,
                      activeFillColor: Colors.orange),
                  cursorColor: Colors.black,
                  animationDuration: Duration(milliseconds: 300),
                  textStyle: TextStyle(fontSize: 20, height: 1.6),
                  enableActiveFill: true,
                  //errorAnimationController: _errorController,
                  controller: _smsCodeController,
                  keyboardType: TextInputType.number,
                  boxShadows: [
                    BoxShadow(
                      offset: Offset(0, 1),
                      color: Colors.black12,
                      blurRadius: 10,
                    )
                  ],
                  onCompleted: (value) => verify(value),
                  onChanged: (value) => {},
                )
              ]
            ]),
          )),
    );
  }

  void send() async {
    setState(() => _isLoading = true);
    if (_formKey.currentState.validate()) {
      FirebaseAuth.instance.verifyPhoneNumber(
          phoneNumber: '+852' + _phoneNumberController.text,
          verificationCompleted: (PhoneAuthCredential credential) async {
            await Auth().signInWithPhoneNumber(credential);
            _scaffoldKey.currentState
                .showSnackBar(SnackBar(content: Text('Signed in!')));
          },
          codeSent: (String verificationId, int resendToken) async {
            _scaffoldKey.currentState.showSnackBar(SnackBar(
                content: Text(
                    'A verification code has been sent to your phone number.')));
            setState(() => _resendToken = resendToken);
            setState(() => _verificationId = verificationId);
          },
          forceResendingToken: _resendToken,
          codeAutoRetrievalTimeout: (String verificationId) async {},
          verificationFailed: (FirebaseAuthException e) async {
            if (e.code == 'invalid-phone-number') {
              _scaffoldKey.currentState.showSnackBar(SnackBar(
                  content: Text('The provided phone number is not valid.')));
            } else {
              _scaffoldKey.currentState.showSnackBar(SnackBar(
                  content: Text('Something went wrong, please try again.')));
            }
          });
    }
    setState(() => _isLoading = false);
  }

  void verify(smsCode) async {
    setState(() => _isLoading = true);
    PhoneAuthCredential phoneAuthCredential = PhoneAuthProvider.credential(
        verificationId: _verificationId, smsCode: smsCode);
    try {
      UserCredential userCredential =
          await Auth().signInWithPhoneNumber(phoneAuthCredential);
      if (await Store().getUser(userCredential.user.uid) == null) {
        Store().createUser(userCredential.user.uid, {
          'email': userCredential.user.email,
          'phoneNumber': userCredential.user.phoneNumber,
          'name': userCredential.user.displayName,
          'createdAt': new DateTime.now()
        });
      }
      _scaffoldKey.currentState
          .showSnackBar(SnackBar(content: Text('Signed in!')));
    } on FirebaseAuthException catch (e) {
      if (e.code == 'invalid-verification-code') {
        _scaffoldKey.currentState.showSnackBar(SnackBar(
            content: Text('Wrong verification code, please try again.')));
      } else {
        _scaffoldKey.currentState.showSnackBar(
            SnackBar(content: Text('Something went wrong, please try again.')));
      }
    }
    setState(() => _isLoading = false);
  }
}
