class MyUser{

  final String uid;

  MyUser({ this.uid });

}

class MyUserInfo{
  final String name;
  final String email;
  final String phoneNumber;
  final String uid;
  final Map <dynamic,dynamic> userAccInfo;
  MyUserInfo({this.uid,this.name,this.email,this.phoneNumber,this.userAccInfo});

}