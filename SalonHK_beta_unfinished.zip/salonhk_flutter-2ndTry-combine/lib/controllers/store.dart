import 'package:cloud_firestore/cloud_firestore.dart';

class Store {

  CollectionReference users = FirebaseFirestore.instance.collection('users');

  Future<void> createUser(String id, Map<String, dynamic> data) async {
    return users
        .doc(id)
        .set(data)
        .then((value) => print("User Added"))
        .catchError((error) => print("Failed to add user: $error"));
  }

  Future<Map<String, dynamic>> getUser(String id) async {
    try {
      DocumentSnapshot user = await users.doc(id).get();
      if (!user.exists) return null;
      return user.data();
    } catch (e) {
      throw e;
    }
  }

}
