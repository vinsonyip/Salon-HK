import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:salonhk_flutter/models/user.dart';

class DatabaseService {
  final String uid;

  DatabaseService({this.uid});

  final CollectionReference userCollection = FirebaseFirestore.instance.collection('users');

  Future<void> updateUserData(String id, Map<String, dynamic> data) async{
    return userCollection
        .doc(id)
        .update(data)
        .then((value) => print('Data Updated'))
        .catchError((error) => print("Failed to add user: $error"));
  }


  List<MyUserInfo> _userInfoListFromSnapshot(QuerySnapshot snapshot) {
    return snapshot.docs.map((doc) {


    try{
      Map<dynamic,dynamic> markMap = doc.data()['userInfo'];
      print(markMap['bookingRec'][0]['BookingDetails']['branchIconAddr']);

//      markMap.forEach((element){
//
//      });
      print("Testing - -- - -- - -: "+ doc.data()['phoneNumber']);
    }catch(e){
      print('No data provided ----------+++++ -___ =-=-= ');
    }
      return MyUserInfo(
          uid: doc.data()['uid'],
          name: doc.data()['name'],
          email: doc.data()['email'],
          phoneNumber: doc.data()['phone'],
          userAccInfo: doc.data()['userInfo']
      );
    }).toList();
  }

  Stream<List<MyUserInfo>> get users {
    return userCollection.snapshots().map(_userInfoListFromSnapshot);
  }
}
