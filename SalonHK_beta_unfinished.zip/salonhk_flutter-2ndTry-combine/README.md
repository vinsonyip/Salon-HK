# salonhk_flutter

A mobile salon guide.

## Initializing

    git clone https://github.com/Woodylai24/salonhk_flutter
    cd salonhk_flutter
    flutter pub get

Now run main.dart on your Android device and it should be built automatically.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.dev/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.dev/docs/cookbook)

For help getting started with Flutter, view our
[online documentation](https://flutter.dev/docs), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
