There are only two demo account:
	1. Email : johnliu1997@gmail.com
	    Password : test1234
	
	2. Email : lily@gmail.com
	    Password : test1234


Note : 
	1. You can only use "Register with E-mail" to register new empty account.
	2. Don't use Google and Facebook sign in
	3. 

	!!!! If you don't follow the rules, the app may occurs many errors !!!!
	!!!! Some errors are irreversible 			   	   !!!!



If you faced the irreversible problems, please contact: ab934438@connect.hku.hk

Some functions still not finished yet... 
 